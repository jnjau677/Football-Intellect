/**
 * Simple in-memory cache with TTL (Time To Live)
 * Used for caching static data like leagues and teams
 */
export class Cache<T> {
  private store = new Map<string, { data: T; expiresAt: number }>();

  /**
   * Set a value in cache with TTL in milliseconds (default 5 minutes)
   */
  set(key: string, data: T, ttlMs: number = 5 * 60 * 1000): void {
    this.store.set(key, { data, expiresAt: Date.now() + ttlMs });
  }

  /**
   * Get a value from cache if not expired
   */
  get(key: string): T | undefined {
    const item = this.store.get(key);
    if (!item) return undefined;

    if (Date.now() > item.expiresAt) {
      this.store.delete(key);
      return undefined;
    }

    return item.data;
  }

  /**
   * Invalidate a specific cache key
   */
  invalidate(key: string): void {
    this.store.delete(key);
  }

  /**
   * Clear all cache
   */
  clear(): void {
    this.store.clear();
  }

  /**
   * Get cache statistics (useful for debugging)
   */
  stats(): { size: number; keys: string[] } {
    return {
      size: this.store.size,
      keys: Array.from(this.store.keys()),
    };
  }
}

// Global cache instances
export const leaguesCache = new Cache();
export const teamsCache = new Cache();
export const standingsCache = new Cache();
