import type { Request, Response, NextFunction } from "express";
import { z } from "zod";

// Rate limiting in-memory store
const rateLimitStore = new Map<string, { count: number; resetTime: number }>();

/**
 * Simple rate limiting middleware for expensive operations (AI predictions)
 * Limits to 10 requests per minute per IP
 */
export function rateLimitMiddleware(
  windowMs: number = 60000,
  maxRequests: number = 10
) {
  return (req: Request, res: Response, next: NextFunction) => {
    const key = req.ip || "unknown";
    const now = Date.now();

    let record = rateLimitStore.get(key);

    if (!record || record.resetTime < now) {
      rateLimitStore.set(key, { count: 1, resetTime: now + windowMs });
      next();
    } else if (record.count < maxRequests) {
      record.count++;
      next();
    } else {
      res.status(429).json({
        message: "Too many requests. Please try again later.",
        retryAfter: Math.ceil((record.resetTime - now) / 1000),
      });
    }
  };
}

/**
 * Request validation middleware
 */
export function validateRequest(schema: z.ZodSchema) {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      const validated = schema.parse(req.body);
      req.body = validated;
      next();
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({
          message: "Validation error",
          errors: error.errors.map((e) => ({
            field: e.path.join("."),
            message: e.message,
          })),
        });
      }
      next(error);
    }
  };
}

/**
 * CORS configuration for security
 */
export function setupCors(req: Request, res: Response, next: NextFunction) {
  const origin = req.headers.origin || "*";
  const allowedOrigins = [
    "http://localhost:5000",
    "http://localhost:3000",
    process.env.APP_URL,
  ];

  if (
    process.env.NODE_ENV === "development" ||
    allowedOrigins.includes(origin)
  ) {
    res.setHeader("Access-Control-Allow-Origin", origin);
  }

  res.setHeader(
    "Access-Control-Allow-Methods",
    "GET, POST, PUT, DELETE, OPTIONS"
  );
  res.setHeader(
    "Access-Control-Allow-Headers",
    "Content-Type, Authorization"
  );
  res.setHeader("Access-Control-Max-Age", "3600");

  if (req.method === "OPTIONS") {
    return res.sendStatus(200);
  }

  next();
}

/**
 * Error handling middleware
 */
export function errorHandler(
  err: any,
  req: Request,
  res: Response,
  next: NextFunction
) {
  const status = err.status || err.statusCode || 500;
  const isDev = process.env.NODE_ENV === "development";

  const message =
    err.message || "Internal Server Error";
  const response: any = { message };

  // Only expose stack trace in development
  if (isDev && err.stack) {
    response.stack = err.stack;
  }

  res.status(status).json(response);
  
  // Log errors for debugging
  if (status >= 500) {
    console.error(`[ERROR] ${status}: ${message}`, err);
  }
}
