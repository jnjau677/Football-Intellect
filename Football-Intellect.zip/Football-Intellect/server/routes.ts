import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import OpenAI from "openai";
import { rateLimitMiddleware } from "./middleware";
import type { InsertTeam } from "@shared/schema";

// Initialize OpenAI client with proper error handling
const openai = new OpenAI({
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY,
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
});

// Validation schemas
const leagueSchema = z.object({
  name: z.string().min(2).max(100),
  country: z.string().min(2).max(100),
  logoUrl: z.string().url().optional(),
});

const matchQuerySchema = z.object({
  leagueId: z.coerce.number().optional(),
  limit: z.coerce.number().int().positive().max(100).default(50),
  offset: z.coerce.number().int().nonnegative().default(0),
});

/**
 * Seed database with initial data
 * Runs only once on startup
 */
async function seedDatabase() {
  try {
    const leagues = await storage.getLeagues();
    if (leagues.length > 0) {
      console.log("[Database] Skipping seed - data already exists");
      return;
    }

    console.log("[Database] Seeding initial data...");

    // Create leagues
    const pl = await storage.createLeague({
      name: "Premier League",
      country: "England",
      logoUrl: "https://resources.premierleague.com/premierleague/logos/PL-logo.svg",
    });

    // Create teams for Premier League with proper typing
    const plTeams: InsertTeam[] = [
      {
        leagueId: pl.id,
        name: "Arsenal",
        position: 1,
        matches_played: 34,
        wins: 21,
        draws: 8,
        losses: 5,
        goals_for: 68,
        goals_against: 32,
        points: 71,
        form: ["W", "W", "D", "W", "L"],
      },
      {
        leagueId: pl.id,
        name: "Liverpool",
        position: 2,
        matches_played: 34,
        wins: 20,
        draws: 8,
        losses: 6,
        goals_for: 72,
        goals_against: 28,
        points: 68,
        form: ["W", "W", "W", "D", "W"],
      },
    ];

    const teams = [];
    for (const team of plTeams) {
      teams.push(await storage.createTeam(team));
    }

    // Create sample matches
    const now = new Date();
    await storage.createMatch({
      leagueId: pl.id,
      homeTeamId: teams[0].id,
      awayTeamId: teams[1].id,
      homeScore: 2,
      awayScore: 1,
      status: "live",
      minute: 67,
      startTime: now,
      homeShots: 8,
      awayShots: 5,
      homePossession: 55.2,
      awayPossession: 44.8,
    });

    console.log("[Database] Seed completed successfully");
  } catch (error) {
    console.error("[Database] Seed failed:", error);
    throw error;
  }
}

/**
 * Generate AI prediction with rate limiting and proper error handling
 */
async function generateSmartPrediction(
  match: any,
  homeTeam: any,
  awayTeam: any
) {
  const homeWinRate = homeTeam.matches_played > 0
    ? ((homeTeam.wins / homeTeam.matches_played) * 100).toFixed(0)
    : "0";
  const awayWinRate = awayTeam.matches_played > 0
    ? ((awayTeam.wins / awayTeam.matches_played) * 100).toFixed(0)
    : "0";

  const prompt = `You are an expert football analyst. Analyze this match and provide predictions.

HOME: ${homeTeam.name} (Pos: ${homeTeam.position}, Pts: ${homeTeam.points}, Win%: ${homeWinRate}%, Form: ${homeTeam.form?.join("")})
AWAY: ${awayTeam.name} (Pos: ${awayTeam.position}, Pts: ${awayTeam.points}, Win%: ${awayWinRate}%, Form: ${awayTeam.form?.join("")})

Return ONLY valid JSON with: analysis (2 sentences), prediction (Home Win|Draw|Away Win), confidence (75-95), homeWinChance, drawChance, awayWinChance, keyInsights (3 insights).`;

  const response = await openai.chat.completions.create({
    model: "gpt-5.1",
    messages: [{ role: "user", content: prompt }],
    response_format: { type: "json_object" },
    max_completion_tokens: 500,
  });

  const content = response.choices[0]?.message?.content || "{}";
  return JSON.parse(content);
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Seed database
  await seedDatabase();

  /**
   * GET /api/leagues
   * Returns all available leagues
   */
  app.get(api.leagues.list.path, async (req, res, next) => {
    try {
      const leagues = await storage.getLeagues();
      res.json(leagues);
    } catch (error) {
      next(error);
    }
  });

  /**
   * GET /api/matches
   * Returns matches with optional filtering and pagination
   */
  app.get(api.matches.list.path, async (req, res, next) => {
    try {
      const { leagueId, limit, offset } = matchQuerySchema.parse(req.query);
      const matches = await storage.getMatches(leagueId, limit, offset);
      res.json(matches);
    } catch (error) {
      next(error);
    }
  });

  /**
   * GET /api/matches/:id
   * Returns a single match with details and prediction
   */
  app.get(api.matches.get.path, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid match ID" });
      }

      const match = await storage.getMatch(id);
      if (!match) return res.status(404).json({ message: "Match not found" });
      res.json(match);
    } catch (error) {
      next(error);
    }
  });

  /**
   * POST /api/matches/:id/predict
   * Generate AI prediction for a match (rate limited)
   */
  app.post(
    api.matches.predict.path,
    rateLimitMiddleware(60000, 10),
    async (req, res, next) => {
      try {
        const id = parseInt(req.params.id);
        if (isNaN(id)) {
          return res.status(400).json({ message: "Invalid match ID" });
        }

        const match = await storage.getMatch(id);
        if (!match) return res.status(404).json({ message: "Match not found" });

        // Check if prediction already exists (avoid regenerating)
        const existing = await storage.getPrediction(id);
        if (existing) return res.json(existing);

        // Generate prediction
        const result = await generateSmartPrediction(
          match,
          match.homeTeam,
          match.awayTeam
        );

        const prediction = await storage.createPrediction({
          matchId: id,
          analysis: result.analysis || "Analysis unavailable",
          prediction: result.prediction || "Unknown",
          confidence: result.confidence || 0,
          homeWinChance: result.homeWinChance,
          drawChance: result.drawChance,
          awayWinChance: result.awayWinChance,
          keyInsights: result.keyInsights,
        });

        res.json(prediction);
      } catch (error) {
        next(error);
      }
    }
  );

  /**
   * GET /api/teams
   * Returns all teams or teams from a specific league
   */
  app.get(api.teams.list.path, async (req, res, next) => {
    try {
      const leagueId = req.query.leagueId
        ? parseInt(req.query.leagueId as string)
        : undefined;
      const teams = await storage.getTeams(leagueId);
      res.json(teams);
    } catch (error) {
      next(error);
    }
  });

  /**
   * GET /api/teams/:id
   * Returns a single team with league info
   */
  app.get(api.teams.get.path, async (req, res, next) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid team ID" });
      }

      const team = await storage.getTeam(id);
      if (!team) return res.status(404).json({ message: "Team not found" });
      res.json(team);
    } catch (error) {
      next(error);
    }
  });

  return httpServer;
}
